/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/*      The game will contain three overall objects:
 *          The model - to hold the state of the game: location of each ship included where it's been hit.
 *          The view - to update the visual display of the game.
 *          The controller - connects the model and view by handling user input, ensuring the logic of the game is played and determining when the game is over.
 */


var view = {
    // Takes a string message and displays it in the message display area
    displayMessage: function(msg) {
        var messageArea = document.getElementById("messageArea");
            messageArea.innerHTML = msg;
        
    },
    displayHit: function(location) {
        var cell = document.getElementById(location);
            cell.setAttribute("class", "hit");
    },
    
    displayMiss: function(location) {
        var cell = document.getElementById(location);
        cell.setAttribute("class", "miss");
    }
};
// End of view object.



var model = {
    
boardSize: 7,
numShips: 3,
shipLength: 3,
shipsSunk: 0,

// The ships: Three ship objects contained in one ships array. The ships array is a property of the model object.
// Each ship object has a locations property(array) containing the three cells on which the ship is located.
// Each ship also has a hits property(array) to which we can contain the hits.
ships: [
    { locations: ["10", "20", "30"], hits: ["", "", ""] },
    { locations: ["32", "33", "34"], hits: ["", "", ""] },
    { locations: ["63", "64", "65"], hits: ["", "", ""] }
],

// Fire method takes a guess and goes through the ships locations to check for a hit.
// if a location is detected it returns true, if not false.
fire: function(guess) {
    for( var i = 0; i < this.numShips; i++ ) {
        var ship = this.ships[i];
            var index = ship.locations.indexOf(guess); // indexOf method takes a value and returns the index of the value in the string. If no match is found it returns -1.
                if( index >= 0) {
                    ship.hits[index] = "hit";
                    view.displayHit(guess);
                    view.displayMessage("HIT!");
                    if( this.isSunk(ship)) { // Calls the isSunk method to check if the ship currently being checked is sunk. If so it increments the shipsSunk property of the model object.
                        view.displayMessage("You sank my battleship!");
                        this.shipsSunk++;
                    }
                    return true;
                }
    }
    view.displayMiss(guess);
    view.displayMessage("You missed.");
    return false; // The method can only return one value. So if it finds a match and returns true then it skips the false return statement.
},

// Call this function to check if a given ship is sunk.
// Takes the ship and returns false if one of the indexes of its hits array DOES NOT contain "hit".
isSunk: function(ship) {
    for( var i = 0; i < this.shipLength; i++ ) {
        if( ship.hits[i] !== "hit" ) {
            return false;
        }
    }
    return true; // Return true if all the hits indexes is equal to "hit".
}

};
// End of model object



var controller = {
    guesses: 0,
    
    processGuess: function(guess) {
        // Check that the guess is valid
        var location = parseGuess(guess);
        
        if( location ) { // If location is a true value meaning NOT null.
            this.guesses++;
            var hit = model.fire(location); // Fire at the location and save the returned value (if any). The only thing returned is true if it hits a shits location.
            
            if( hit && model.shipsSunk === model.numShips ) { // The most recent hit is true and the ships sunk is equal to the number of ships in the game, the game is over.
                view.displayMessage( "You sank all my battleships, in " + this.guesses + " guesses" );
            }
        }
 
        return this.guesses;
    }
};
    
// Convert the guess to correspond with the grid format: A0 becomes 00
function parseGuess(guess) {
    var alphabet = ["A", "B", "C", "D", "E", "F", "G"];
        
    if( guess === null || guess.length !== 2 ) {
        alert("Please enter a letter and a number on the board. Ex: A0"); 
    } else {
        var firstChar = guess.charAt(0); // Get the first char in the guess.
        var row = alphabet.indexOf(firstChar); // Check it against the alphabet variable and change the letter to the corresponding number: A becomes 0.
        var column = guess.charAt(1); // Get the second char in the guess.
            
        if( isNaN(row) || isNaN(column) ) { // Check if both inputted chars are correct formatted (i.e. numbers).
            alert("Oops, that isn't on the board.");
        } else if ( row < 0 || row >= model.boardSize || column < 0 || column >= model.boardSize ) { // Check if both inputted numbers are within the boards borders. Using type conversion to compare string and number.
            alert("Oops, that's off the board.");
        } else {
            return row + column; // If the guess is correct we concatenate the row and column into a single string and return it.
        }
    }
    return null; // If we get here, there was a failed check along the way during one of the if-statement, so we return null.
};
    

  
// Handle the fire button.
function init() {
    var fireButton = document.getElementById("fireButton");
    fireButton.onclick = handleFireButton;
    var guessInput = document.getElementById("guessInput");
    guessInput.onkeypress = handleKeyPress;
}


function handleKeyPress( event ) {
    var fireButton = document.getElementById("fireButton");
    if( event.keyCode === 13 ) {
        fireButton.click();
        return false;
    }
}


function handleFireButton() {
    var guessInput = document.getElementById("guessInput");
    var guess = guessInput.value;
    controller.processGuess(guess);
    
    guessInput.value = "";
}

window.onload = init;